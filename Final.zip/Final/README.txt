Official Site του project μας στο github: https://github.com/Konstantinos-Papanagnou/Project-Management

Αναφορές: 
	Στο αρχείο "Final Report.*" μπορείτε να δείτε το γενικό παραδοτέο με όλη την αναλύση που απαιτείται.
	Στο αρχείο "User Manual.*" μπορείτε να δείτε το User Manual που δημιουργησε ο Παναγιώτης Σκλίδας
	Στο αρχείο "Documentation.*" μπορείτε να δείτε το Documentation του κώδικα μας

Πρόγραμμα: 
	Στον φάκελο Installer υπάρχει το τελευταίο stable release που βγάλαμε το οποίο μπορείτε να εγκαταστήσετε. Μέσα σε αυτον τον φάκελο θα βρείτε αναλυτικές οδηγίες για την εγκατάσταση και την ρύθμιση του προγράμματος μας. Σε περίπτωση που θέλετε να δείτε τα προηγούμενα releases μπορείτε να τα βρείτε στο official site του project στο github κάτω από τον φάκελο "Releases"

Διαγράμματα:
	Στον φάκελο Charts υπάρχουν όλα τα διαγράμματα που δημιουργήθηκαν και χρησιμοποιήθηκαν από την ομάδα μας στην τελική αναφορά (Με τα αρχεία visio και visual paradigm καθώς και τις εικόνες τους.) Για να δείτε τα αρχεία που προκύπτουν από τις εφαρμογές θα χρειαστείτε μερικά προγράμματα όπως Microsoft Visio, Visual Paradigm Community (Είναι σημαντικό να είναι το community και όχι κάποιο professional edition.) και την διαδικτυακή πλατφόρμα draw.io (https://app.diagrams.net/) για να ανοίξετε τα αρχεία ".drawio"

Κώδικας:
	Ο κώδικας μας είναι γραμμένος στην γλώσσα C# το οποίο σημαίνει πως πρέπει να εγκαταστήσετε το visual studio για να το δείτε οργανωμένο και να το εκτελέσετε. (Ανοίγει και με το Visual Studio Code αλλά δεν θα μπορείτε να το εκτελέσετε χωρίς κάποιο plugin) Η έκδοση του Visual Studio που απαιτείται για να ανοίξει το project είναι η 2019 (Visual Studio 2019) και μπορείτε να το κατεβάσετε από αυτήν την σελίδα (Δεν έχει σημασία αν είναι community/professional/enterprise): https://visualstudio.microsoft.com/vs/
	Για να φορτώσετε το project μας στο visual studio το μόνο που πρέπει να κάνετε είναι διπλό κλικ στο αρχείο "PharmacyInformationSystem.sln" στον φάκελο "PharmacyInformationSystem". Όλα τα υπόλοιπα θα τα χειριστεί το visual studio αυτόματα.